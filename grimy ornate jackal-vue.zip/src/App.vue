
<template>
  <router-view/>
</template>