<template>
  <div class="purchase-container">
    <div class="purchase-container01">
      <router-link to="/" class="purchase-navlink">
        <img
          alt="image"
          src="/yellow%20minimalist%20thunder%20power%20logo%20(4)-200h.png"
          class="purchase-image"
        />
      </router-link>
      <span class="purchase-text">RFID Payment System</span>
    </div>
    <div class="purchase-container02">
      <span class="purchase-text1">Cart</span>
      <div class="purchase-container03">
        <div class="purchase-container04"></div>
        <div class="purchase-container05"></div>
        <div class="purchase-container06"></div>
      </div>
      <div class="purchase-container07">
        <div class="purchase-container08"></div>
        <div class="purchase-container09"></div>
        <div class="purchase-container10"></div>
      </div>
    </div>
    <div class="purchase-container11">
      <div class="purchase-container12">
        <div class="purchase-container13">
          <router-link to="/" class="purchase-text2">Purchase</router-link>
          <router-link to="/recharge" class="purchase-navlink1">
            <span>Recharge</span>
            <br />
          </router-link>
          <span class="purchase-text5">Balance</span>
          <span class="purchase-text6">Logs</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Purchase',
  props: {},
  metaInfo: {
    title: 'Grimy Ornate Jackal',
    meta: [
      {
        property: 'og:title',
        content: 'Grimy Ornate Jackal',
      },
    ],
  },
}
</script>

<style scoped>
.purchase-container {
  width: 100%;
  display: flex;
  min-height: 100vh;
  align-items: flex-start;
  flex-direction: column;
  justify-content: flex-start;
}
.purchase-container01 {
  width: 100%;
  height: 157px;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  background-color: #436579;
}
.purchase-navlink {
  display: contents;
}
.purchase-image {
  width: 177px;
  height: 177px;
  object-fit: cover;
  text-decoration: none;
}
.purchase-text {
  fill: #FBBB5A;
  color: #FBBB5A;
  font-size: 35px;
  align-self: center;
  font-style: normal;
  font-family: "Poppins";
  font-weight: 600;
  margin-left: var(--dl-space-space-unit);
}
.purchase-container02 {
  top: 4px;
  left: 0px;
  width: 1203px;
  height: 996px;
  display: flex;
  position: absolute;
  margin-top: 150px;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: hidden;
  border-width: 2px;
  justify-content: center;
}
.purchase-text1 {
  top: var(--dl-space-space-threeunits);
  left: 245px;
  position: absolute;
  font-size: 30px;
  font-style: normal;
  font-family: "Poppins";
  font-weight: 600;
}
.purchase-container03 {
  top: 0px;
  flex: 0 0 auto;
  left: 0px;
  width: 100%;
  display: flex;
  position: absolute;
  align-self: center;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: hidden;
  border-width: 2px;
}
.purchase-container04 {
  top: 420px;
  flex: 0 0 auto;
  left: 325px;
  width: 205px;
  height: 197px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: solid;
  border-width: 2px;
  border-radius: var(--dl-radius-radius-radius8);
  background-color: #EDEFF1;
}
.purchase-container05 {
  top: 420px;
  flex: 0 0 auto;
  left: 590px;
  width: 205px;
  height: 197px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: solid;
  border-width: 2px;
  border-radius: var(--dl-radius-radius-radius8);
  background-color: #EDEFF1;
}
.purchase-container06 {
  top: 420px;
  flex: 0 0 auto;
  left: 855px;
  width: 205px;
  height: 197px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: solid;
  border-width: 2px;
  border-radius: var(--dl-radius-radius-radius8);
  background-color: #EDEFF1;
}
.purchase-container07 {
  top: 0px;
  flex: 0 0 auto;
  left: 0px;
  width: 100%;
  height: 198px;
  display: flex;
  position: absolute;
  align-items: flex-start;
}
.purchase-container08 {
  top: 150px;
  flex: 0 0 auto;
  left: 325px;
  width: 205px;
  height: 197px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: solid;
  border-width: 2px;
  border-radius: var(--dl-radius-radius-radius8);
  background-color: #EDEFF1;
}
.purchase-container09 {
  top: 150px;
  flex: 0 0 auto;
  left: 590px;
  width: 205px;
  height: 197px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: solid;
  border-width: 2px;
  border-radius: var(--dl-radius-radius-radius8);
  background-color: #EDEFF1;
}
.purchase-container10 {
  top: 150px;
  flex: 0 0 auto;
  left: 855px;
  width: 205px;
  height: 197px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: solid;
  border-width: 2px;
  border-radius: var(--dl-radius-radius-radius8);
  background-color: #EDEFF1;
}
.purchase-container11 {
  flex: 0 0 auto;
  width: auto;
  height: 1000px;
  display: flex;
  position: relative;
  align-items: flex-start;
  justify-content: flex-start;
}
.purchase-container12 {
  flex: 0 0 auto;
  width: auto;
  height: 1000px;
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
}
.purchase-container13 {
  width: 193px;
  height: 1071px;
  display: flex;
  position: relative;
  align-items: flex-start;
  border-color: var(--dl-color-theme-neutral-dark);
  border-style: solid;
  border-width: 1px;
  flex-direction: column;
  border-top-width: 0px;
  border-left-width: 0px;
}
.purchase-text2 {
  align-self: center;
  font-style: normal;
  margin-top: 55px;
  font-family: "Poppins";
  font-weight: 500;
  text-decoration: none;
}
.purchase-navlink1 {
  align-self: center;
  font-style: normal;
  margin-top: var(--dl-space-space-fiveunits);
  font-family: "Poppins";
  font-weight: 500;
  text-decoration: none;
}
.purchase-text5 {
  align-self: center;
  font-style: normal;
  margin-top: var(--dl-space-space-fiveunits);
  font-family: "Poppins";
  font-weight: 500;
}
.purchase-text6 {
  align-self: center;
  margin-top: var(--dl-space-space-fiveunits);
  font-family: "Poppins";
  font-weight: 500;
}
</style>
