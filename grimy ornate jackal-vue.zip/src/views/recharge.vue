<template>
  <div class="recharge-container">
    <div class="recharge-container1">
      <router-link to="/" class="recharge-navlink">
        <img
          alt="image"
          src="/yellow%20minimalist%20thunder%20power%20logo%20(4)-200h.png"
          class="recharge-image"
        />
      </router-link>
      <span class="recharge-text">RFID Payment System</span>
    </div>
    <div class="recharge-container2">
      <span class="recharge-text1">Recharge</span>
    </div>
    <div class="recharge-container3">
      <div class="recharge-container4">
        <div class="recharge-container5">
          <router-link to="/" class="recharge-text2">Purchase</router-link>
          <span class="recharge-text3">
            <span>Recharge</span>
            <br />
          </span>
          <span class="recharge-text6">Balance</span>
          <span class="recharge-text7">Logs</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Recharge',
  props: {},
  metaInfo: {
    title: 'Recharge - Grimy Ornate Jackal',
    meta: [
      {
        property: 'og:title',
        content: 'Recharge - Grimy Ornate Jackal',
      },
    ],
  },
}
</script>

<style scoped>
.recharge-container {
  width: 100%;
  display: flex;
  min-height: 100vh;
  align-items: flex-start;
  flex-direction: column;
  justify-content: flex-start;
}
.recharge-container1 {
  width: 100%;
  height: 157px;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  background-color: #436579;
}
.recharge-navlink {
  display: contents;
}
.recharge-image {
  width: 177px;
  height: 177px;
  object-fit: cover;
  text-decoration: none;
}
.recharge-text {
  fill: #FBBB5A;
  color: #FBBB5A;
  font-size: 35px;
  align-self: center;
  font-style: normal;
  font-family: "Poppins";
  font-weight: 600;
  margin-left: var(--dl-space-space-unit);
}
.recharge-container2 {
  top: 4px;
  left: 0px;
  width: 1203px;
  height: 996px;
  display: flex;
  position: absolute;
  margin-top: 150px;
  align-items: flex-start;
  border-color: rgba(120, 120, 120, 0.4);
  border-style: hidden;
  border-width: 2px;
  justify-content: center;
}
.recharge-text1 {
  top: 300px;
  left: 630px;
  position: absolute;
  font-size: 30px;
  font-style: normal;
  font-family: "Poppins";
  font-weight: 600;
}
.recharge-container3 {
  flex: 0 0 auto;
  width: auto;
  height: 1000px;
  display: flex;
  position: relative;
  align-items: flex-start;
  justify-content: flex-start;
}
.recharge-container4 {
  flex: 0 0 auto;
  width: auto;
  height: 1000px;
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
}
.recharge-container5 {
  width: 193px;
  height: 1071px;
  display: flex;
  position: relative;
  align-items: flex-start;
  border-color: var(--dl-color-theme-neutral-dark);
  border-style: solid;
  border-width: 1px;
  flex-direction: column;
  border-top-width: 0px;
  border-left-width: 0px;
}
.recharge-text2 {
  align-self: center;
  font-style: normal;
  margin-top: 55px;
  font-family: "Poppins";
  font-weight: 500;
  text-decoration: none;
}
.recharge-text3 {
  align-self: center;
  font-style: normal;
  margin-top: var(--dl-space-space-fiveunits);
  font-family: "Poppins";
  font-weight: 500;
  text-decoration: none;
}
.recharge-text6 {
  align-self: center;
  font-style: normal;
  margin-top: var(--dl-space-space-fiveunits);
  font-family: "Poppins";
  font-weight: 500;
}
.recharge-text7 {
  align-self: center;
  margin-top: var(--dl-space-space-fiveunits);
  font-family: "Poppins";
  font-weight: 500;
}
</style>
